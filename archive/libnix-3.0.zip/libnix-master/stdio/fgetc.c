#include <stdio.h>

int fgetc(FILE *stream)
{ return getc(stream); }
