#include <locale.h>

struct lconv __lconv;
