#include <proto/mathieeesingbas.h>

float __mulsf3(float x,float y)
{ return IEEESPMul(x,y); }
