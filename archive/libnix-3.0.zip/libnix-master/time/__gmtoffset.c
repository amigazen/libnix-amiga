/* Greenwich mean time offset and daylight savings time flag 
 */

long __gmtoffset=0;
int  __dstflag=0;
