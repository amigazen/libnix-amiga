#include <proto/timer.h>
ULONG __timerunit = UNIT_MICROHZ;
