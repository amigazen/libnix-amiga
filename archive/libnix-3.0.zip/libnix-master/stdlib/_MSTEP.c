#include <exec/types.h>

ULONG _MSTEP=16384;

/* suggestion of Gerhard M�ller to be more SAS alike */
