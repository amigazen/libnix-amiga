int abs(int j)
{ return j>=0?j:-j; }
