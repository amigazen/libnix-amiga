#include <stdio.h>
#include <stdlib.h>

int atoi(const char *nptr)
{ return strtol(nptr,NULL,10); }
