
char *dgettext(const char *domainname __attribute__((unused)), const char *msg)
{
	return((char *) msg );
}
