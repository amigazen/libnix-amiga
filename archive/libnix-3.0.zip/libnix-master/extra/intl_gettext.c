
char *gettext(const char *msg)
{
	return((char *) msg );
}
