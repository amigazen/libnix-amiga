#include "stabs.h"

ALIAS(unlink,remove);
