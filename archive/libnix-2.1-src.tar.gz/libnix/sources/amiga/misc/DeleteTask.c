#include "stabs.h"

ALIAS(DeleteTask,RemTask);
