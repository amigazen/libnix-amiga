#include "stabs.h"

ABSDEF(AbsExecBase,0x00000004);
ABSDEF(cartridge,  0x00f00000);
ABSDEF(bootrom,    0x00f80000);
ABSDEF(romstart,   0x00fc0000);
ABSDEF(romend,     0x00ffffff);
