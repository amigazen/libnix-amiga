#include "stabs.h"

ALIAS(DoPkt0,DoPkt);
ALIAS(DoPkt1,DoPkt);
ALIAS(DoPkt2,DoPkt);
ALIAS(DoPkt3,DoPkt);
ALIAS(DoPkt4,DoPkt);
