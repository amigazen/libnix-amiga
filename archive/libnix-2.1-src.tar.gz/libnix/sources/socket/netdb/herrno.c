int h_errno = 0;
int network_installed = 0;
