/* Replace this with your own if you want */

char __stdiowin[]="CON://///AUTO/CLOSE/WAIT";
