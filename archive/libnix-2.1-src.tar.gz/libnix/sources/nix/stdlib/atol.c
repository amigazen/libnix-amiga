#include <stdio.h>
#include <stdlib.h>

long atol(const char *nptr)
{ return strtol(nptr,NULL,10); }
