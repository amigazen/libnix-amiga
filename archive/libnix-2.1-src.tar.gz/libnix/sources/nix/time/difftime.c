#include <time.h>

double difftime(time_t a,time_t b)
{ return a-b; }
