unsigned char *__decimalpoint=".";
