#include "stabs.h"

ALIAS(rmdir,remove);
