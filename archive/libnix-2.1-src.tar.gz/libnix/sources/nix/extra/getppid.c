#include <unistd.h>

pid_t getppid(void)
{
  return 1; /* init ;-) */
}
