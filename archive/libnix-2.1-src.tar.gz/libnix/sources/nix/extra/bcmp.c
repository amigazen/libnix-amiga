#include "stabs.h"

ALIAS(bcmp,memcmp);
