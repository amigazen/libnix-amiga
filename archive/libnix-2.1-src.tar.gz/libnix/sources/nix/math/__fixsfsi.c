#include <proto/mathieeesingbas.h>

signed long __fixsfsi(float x)
{ return IEEESPFix(x); }
