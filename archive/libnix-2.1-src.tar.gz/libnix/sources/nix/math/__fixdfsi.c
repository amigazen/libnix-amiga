#include <proto/mathieeedoubbas.h>

signed long __fixdfsi(double x)
{ return IEEEDPFix(x); }
