#include <proto/mathieeedoubbas.h>

double __negdf2(double x)
{ return IEEEDPNeg(x); }
