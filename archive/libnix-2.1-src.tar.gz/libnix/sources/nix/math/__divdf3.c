#include <proto/mathieeedoubbas.h>

double __divdf3(double x,double y)
{ return IEEEDPDiv(x,y); }
