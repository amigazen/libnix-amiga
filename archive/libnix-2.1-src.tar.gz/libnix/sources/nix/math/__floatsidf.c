#include <proto/mathieeedoubbas.h>

double __floatsidf(signed long x)
{ return IEEEDPFlt(x); }
