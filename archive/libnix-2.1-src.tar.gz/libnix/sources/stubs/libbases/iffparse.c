/* Machine-generated C-file- do not edit ! */
#include <stabs.h>
extern char __iffparsename[];
void *IFFParseBase[2]={ 0l,__iffparsename };
ADD2LIB(IFFParseBase);
