/* Machine-generated C-file- do not edit ! */
#include <stabs.h>
extern char __mathieeedoubbasname[];
void *MathIeeeDoubBasBase[2]={ 0l,__mathieeedoubbasname };
ADD2LIB(MathIeeeDoubBasBase);
