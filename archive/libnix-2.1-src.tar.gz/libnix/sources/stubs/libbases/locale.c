/* Machine-generated C-file- do not edit ! */
#include <stabs.h>
extern char __localename[];
void *LocaleBase[2]={ 0l,__localename };
ADD2LIB(LocaleBase);
