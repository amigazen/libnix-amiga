/* Machine-generated C-file- do not edit ! */
#include <stabs.h>
extern char __amigaguidename[];
void *AmigaGuideBase[2]={ 0l,__amigaguidename };
ADD2LIB(AmigaGuideBase);
