/* Machine-generated C-file- do not edit ! */
#include <stabs.h>
extern char __keymapname[];
void *KeymapBase[2]={ 0l,__keymapname };
ADD2LIB(KeymapBase);
