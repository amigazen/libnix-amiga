/* Machine-generated C-file- do not edit ! */
#include <stabs.h>
extern char __diskfontname[];
void *DiskfontBase[2]={ 0l,__diskfontname };
ADD2LIB(DiskfontBase);
