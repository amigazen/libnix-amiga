/* Machine-generated C-file- do not edit ! */
#include <stabs.h>
extern char __layersname[];
void *LayersBase[2]={ 0l,__layersname };
ADD2LIB(LayersBase);
