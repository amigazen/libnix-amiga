/* Machine-generated C-file- do not edit ! */
#include <stabs.h>
extern char __mathffpname[];
void *MathBase[2]={ 0l,__mathffpname };
ADD2LIB(MathBase);
