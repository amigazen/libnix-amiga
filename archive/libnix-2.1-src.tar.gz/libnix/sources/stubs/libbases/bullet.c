/* Machine-generated C-file- do not edit ! */
#include <stabs.h>
extern char __bulletname[];
void *BulletBase[2]={ 0l,__bulletname };
ADD2LIB(BulletBase);
