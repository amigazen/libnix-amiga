/* Machine-generated C-file- do not edit ! */
#include <stabs.h>
extern char __rexxsyslibname[];
void *RexxSysBase[2]={ 0l,__rexxsyslibname };
ADD2LIB(RexxSysBase);
