/* Machine-generated C-file- do not edit ! */
#include <stabs.h>
extern char __dosname[];
void *DOSBase[2]={ 0l,__dosname };
ADD2LIB(DOSBase);
