/* Machine-generated C-file- do not edit ! */
#include <stabs.h>
extern char __mathieeesingbasname[];
void *MathIeeeSingBasBase[2]={ 0l,__mathieeesingbasname };
ADD2LIB(MathIeeeSingBasBase);
