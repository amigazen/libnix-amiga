/* Machine-generated C-file- do not edit ! */
#include <stabs.h>
extern char __nonvolatilename[];
void *NVBase[2]={ 0l,__nonvolatilename };
ADD2LIB(NVBase);
