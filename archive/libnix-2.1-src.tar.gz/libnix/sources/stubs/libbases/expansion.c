/* Machine-generated C-file- do not edit ! */
#include <stabs.h>
extern char __expansionname[];
void *ExpansionBase[2]={ 0l,__expansionname };
ADD2LIB(ExpansionBase);
