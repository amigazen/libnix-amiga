/* Machine-generated C-file- do not edit ! */
#include <stabs.h>
extern char __iconname[];
void *IconBase[2]={ 0l,__iconname };
ADD2LIB(IconBase);
