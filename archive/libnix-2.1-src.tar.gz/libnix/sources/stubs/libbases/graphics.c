/* Machine-generated C-file- do not edit ! */
#include <stabs.h>
extern char __graphicsname[];
void *GfxBase[2]={ 0l,__graphicsname };
ADD2LIB(GfxBase);
