/* Machine-generated C-file- do not edit ! */
#include <stabs.h>
extern char __translatorname[];
void *TranslatorBase[2]={ 0l,__translatorname };
ADD2LIB(TranslatorBase);
