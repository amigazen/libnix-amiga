/* Machine-generated C-file- do not edit ! */
#include <stabs.h>
extern char __mathieeedoubtransname[];
void *MathIeeeDoubTransBase[2]={ 0l,__mathieeedoubtransname };
ADD2LIB(MathIeeeDoubTransBase);
