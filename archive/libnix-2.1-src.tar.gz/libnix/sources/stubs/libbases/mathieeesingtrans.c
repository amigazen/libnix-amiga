/* Machine-generated C-file- do not edit ! */
#include <stabs.h>
extern char __mathieeesingtransname[];
void *MathIeeeSingTransBase[2]={ 0l,__mathieeesingtransname };
ADD2LIB(MathIeeeSingTransBase);
