/* Machine-generated C-file- do not edit ! */
#include <stabs.h>
extern char __commoditiesname[];
void *CxBase[2]={ 0l,__commoditiesname };
ADD2LIB(CxBase);
