/* Machine-generated C-file- do not edit ! */
#include <stabs.h>
extern char __gadtoolsname[];
void *GadToolsBase[2]={ 0l,__gadtoolsname };
ADD2LIB(GadToolsBase);
