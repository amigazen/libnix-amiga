/* Machine-generated C-file- do not edit ! */
#include <stabs.h>
extern char __intuitionname[];
void *IntuitionBase[2]={ 0l,__intuitionname };
ADD2LIB(IntuitionBase);
