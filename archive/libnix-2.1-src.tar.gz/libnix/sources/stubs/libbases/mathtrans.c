/* Machine-generated C-file- do not edit ! */
#include <stabs.h>
extern char __mathtransname[];
void *MathTransBase[2]={ 0l,__mathtransname };
ADD2LIB(MathTransBase);
