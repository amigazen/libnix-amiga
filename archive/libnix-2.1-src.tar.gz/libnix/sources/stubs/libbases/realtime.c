/* Machine-generated C-file- do not edit ! */
#include <stabs.h>
extern char __realtimename[];
void *RealTimeBase[2]={ 0l,__realtimename };
ADD2LIB(RealTimeBase);
