/* Machine-generated C-file- do not edit ! */
#include <stabs.h>
extern char __lowlevelname[];
void *LowLevelBase[2]={ 0l,__lowlevelname };
ADD2LIB(LowLevelBase);
