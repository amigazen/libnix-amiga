/* Machine-generated C-file- do not edit ! */
#include <stabs.h>
extern char __aslname[];
void *AslBase[2]={ 0l,__aslname };
ADD2LIB(AslBase);
