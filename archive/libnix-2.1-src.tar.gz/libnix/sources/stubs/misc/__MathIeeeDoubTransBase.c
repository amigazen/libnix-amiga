#include "stabs.h"
extern char __mathieeedoubtransname[];
void *__MathIeeeDoubTransBase[2]={ 0l,__mathieeedoubtransname };
ADD2LIB(__MathIeeeDoubTransBase);
