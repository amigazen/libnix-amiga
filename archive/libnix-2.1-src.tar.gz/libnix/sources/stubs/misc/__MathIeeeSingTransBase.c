#include "stabs.h"
extern char __mathieeesingtransname[];
void *__MathIeeeSingTransBase[2]={ 0l,__mathieeesingtransname };
ADD2LIB(__MathIeeeSingTransBase);
