#include "stabs.h"
extern char __utilityname[];
void *__UtilityBase[2]={ 0l,__utilityname };
ADD2LIB(__UtilityBase);
