/* Machine-generated C-file- do not edit ! */
char __iconname[]="icon.library";
