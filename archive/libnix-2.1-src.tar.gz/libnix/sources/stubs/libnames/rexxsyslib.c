/* Machine-generated C-file- do not edit ! */
char __rexxsyslibname[]="rexxsyslib.library";
