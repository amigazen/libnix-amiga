/* Machine-generated C-file- do not edit ! */
char __mathieeedoubbasname[]="mathieeedoubbas.library";
