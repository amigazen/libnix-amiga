/* Machine-generated C-file- do not edit ! */
char __layersname[]="layers.library";
