/* Machine-generated C-file- do not edit ! */
char __nonvolatilename[]="nonvolatile.library";
