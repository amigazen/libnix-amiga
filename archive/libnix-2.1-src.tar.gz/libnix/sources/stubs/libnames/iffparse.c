/* Machine-generated C-file- do not edit ! */
char __iffparsename[]="iffparse.library";
