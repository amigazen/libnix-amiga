/* Machine-generated C-file- do not edit ! */
char __mathieeesingtransname[]="mathieeesingtrans.library";
