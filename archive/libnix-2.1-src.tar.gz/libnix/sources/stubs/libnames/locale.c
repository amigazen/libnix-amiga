/* Machine-generated C-file- do not edit ! */
char __localename[]="locale.library";
