/* Machine-generated C-file- do not edit ! */
char __mathffpname[]="mathffp.library";
