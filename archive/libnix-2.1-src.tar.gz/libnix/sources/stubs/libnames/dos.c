/* Machine-generated C-file- do not edit ! */
char __dosname[]="dos.library";
