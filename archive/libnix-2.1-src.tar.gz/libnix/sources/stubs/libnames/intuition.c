/* Machine-generated C-file- do not edit ! */
char __intuitionname[]="intuition.library";
