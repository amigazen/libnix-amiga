/* Machine-generated C-file- do not edit ! */
char __bulletname[]="bullet.library";
