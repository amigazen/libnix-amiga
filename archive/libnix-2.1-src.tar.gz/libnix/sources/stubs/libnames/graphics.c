/* Machine-generated C-file- do not edit ! */
char __graphicsname[]="graphics.library";
