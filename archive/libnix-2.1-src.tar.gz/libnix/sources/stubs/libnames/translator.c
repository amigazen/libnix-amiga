/* Machine-generated C-file- do not edit ! */
char __translatorname[]="translator.library";
