/* Machine-generated C-file- do not edit ! */
char __mathieeesingbasname[]="mathieeesingbas.library";
