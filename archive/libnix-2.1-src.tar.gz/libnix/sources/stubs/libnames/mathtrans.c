/* Machine-generated C-file- do not edit ! */
char __mathtransname[]="mathtrans.library";
