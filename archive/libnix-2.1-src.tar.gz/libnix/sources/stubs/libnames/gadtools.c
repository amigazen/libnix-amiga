/* Machine-generated C-file- do not edit ! */
char __gadtoolsname[]="gadtools.library";
