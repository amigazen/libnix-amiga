/* Machine-generated C-file- do not edit ! */
char __commoditiesname[]="commodities.library";
