/* Machine-generated C-file- do not edit ! */
char __keymapname[]="keymap.library";
