unsigned long __stack=4000;
