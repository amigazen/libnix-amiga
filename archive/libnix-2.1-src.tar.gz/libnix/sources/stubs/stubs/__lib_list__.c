void *__LIB_LIST__[2]={ 0,0 };
