void *__EXIT_LIST__[2]={ 0,0 };
