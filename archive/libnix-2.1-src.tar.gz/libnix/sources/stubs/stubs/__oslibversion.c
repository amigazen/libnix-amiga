#include <exec/types.h>
ULONG __oslibversion=37;
