void *__INIT_LIST__[2]={ 0,0 };
