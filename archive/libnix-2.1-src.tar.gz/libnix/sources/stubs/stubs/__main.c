int __main(void) { return 0; }
