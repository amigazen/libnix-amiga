#include "stabs.h"

/* main is now called _main! */
ALIAS(main,_main);
