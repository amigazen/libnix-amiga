#include <proto/mathieeedoubtrans.h>

double sqrt(double x)
{ return IEEEDPSqrt(x); }
