#include <proto/mathieeedoubtrans.h>

double exp(double x)
{ return IEEEDPExp(x); }
