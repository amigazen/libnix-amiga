#include <proto/mathieeedoubbas.h>

double fabs(double x)
{ return IEEEDPAbs(x); }
