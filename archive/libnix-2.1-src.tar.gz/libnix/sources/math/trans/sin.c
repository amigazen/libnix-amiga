#include <proto/mathieeedoubtrans.h>

double sin(double x)
{ return IEEEDPSin(x); }
