#include <proto/mathieeedoubtrans.h>

double log(double x)
{ return IEEEDPLog(x); }
