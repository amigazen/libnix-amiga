#include <proto/mathieeedoubbas.h>

double ceil(double x)
{ return IEEEDPCeil(x); }
