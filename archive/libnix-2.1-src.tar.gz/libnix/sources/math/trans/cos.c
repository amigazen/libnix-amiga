#include <proto/mathieeedoubtrans.h>

double cos(double x)
{ return IEEEDPCos(x); }
