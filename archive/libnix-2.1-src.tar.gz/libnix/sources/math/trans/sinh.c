#include <proto/mathieeedoubtrans.h>

double sinh(double x)
{ return IEEEDPSinh(x); }
