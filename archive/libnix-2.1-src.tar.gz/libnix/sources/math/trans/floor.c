#include <proto/mathieeedoubbas.h>

double floor(double x)
{ return IEEEDPFloor(x); }
