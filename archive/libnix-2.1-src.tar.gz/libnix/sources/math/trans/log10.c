#include <proto/mathieeedoubtrans.h>

double log10(double x)
{ return IEEEDPLog10(x); }
