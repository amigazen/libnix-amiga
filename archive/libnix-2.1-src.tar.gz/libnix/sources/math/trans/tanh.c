#include <proto/mathieeedoubtrans.h>

double tanh(double x)
{ return IEEEDPTanh(x); }
