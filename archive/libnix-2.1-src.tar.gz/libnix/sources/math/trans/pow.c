#include <proto/mathieeedoubtrans.h>

double pow(double x,double y)
{ return IEEEDPPow(y,x); }
