#include <proto/mathieeedoubtrans.h>

double cosh(double x)
{ return IEEEDPCosh(x); }
