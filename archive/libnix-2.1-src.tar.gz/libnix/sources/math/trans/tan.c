#include <proto/mathieeedoubtrans.h>

double tan(double x)
{ return IEEEDPTan(x); }
