#include <proto/mathieeedoubtrans.h>

double acos(double x)
{ return IEEEDPAcos(x); }
