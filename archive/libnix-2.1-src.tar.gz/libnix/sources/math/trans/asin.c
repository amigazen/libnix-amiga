#include <proto/mathieeedoubtrans.h>

double asin(double x)
{ return IEEEDPAsin(x); }
