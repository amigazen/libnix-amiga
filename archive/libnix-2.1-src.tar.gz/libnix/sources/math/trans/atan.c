#include <proto/mathieeedoubtrans.h>

double atan(double x)
{ return IEEEDPAtan(x); }
